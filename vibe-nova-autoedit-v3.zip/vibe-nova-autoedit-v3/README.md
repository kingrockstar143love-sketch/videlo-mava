# VIBE NOVA CLIPS 3.0 — AI Auto Edit

This version integrates the `ai_video_editor` Flutter package (MIT package license) for an on-device AI editing workflow.

## Intended working tools exposed by the editor
- Import videos and open a multi-track timeline editor
- AI Edit from a text or spoken instruction
- AI Shorts / highlight selection
- Automatic removal of silent pauses
- Whisper-based automatic speech captions
- Music synthesis and voice-over tools
- Crop/reframe for 9:16, 16:9, 1:1 and other ratios
- Transitions, filters, text/sticker overlays, speed and volume controls
- Draft saving and MP4 export

## First-run downloads and limitations
- Whisper speech model download is about 40 MB and is used for local speech-to-text.
- Optional Smart AI model download is about 550 MB; basic keyword-rule editing is available without it.
- These model downloads need internet the first time and sufficient free phone storage.
- AI highlight quality, language support and export success depend on the phone, source video and available resources.
- This project has not been built or tested on the user's specific Android phone yet.

## Android setup required by package
- Android `minSdk` must be 26.
- Add INTERNET and RECORD_AUDIO permissions.
- Add the TTS and speech-recognition intent queries.
- Disable Impeller as recommended by the package for some MediaTek devices.

## Build
Use the included `.github/workflows/build-apk.yml` with GitHub Actions.
