import 'package:ai_video_editor/ai_video_editor.dart';
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VibeNovaClipsApp());
}

class VibeNovaClipsApp extends StatelessWidget {
  const VibeNovaClipsApp({super.key});

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFFB88AFF);
    return MaterialApp(
      title: 'VIBE NOVA CLIPS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101018),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9655D9),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF171722),
          foregroundColor: Colors.white,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.0,
          ),
        ),
        useMaterial3: true,
      ),
      home: const VibeNovaHome(),
    );
  }
}

class VibeNovaHome extends StatelessWidget {
  const VibeNovaHome({super.key});

  void _openEditor(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const VideoEntryScreen(),
      ),
    );
  }

  void _openProjects(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const ProjectsScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFFB88AFF);
    return Scaffold(
      appBar: AppBar(
        title: const Text('VIBE NOVA CLIPS'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              gradient: const LinearGradient(
                colors: [Color(0xFF48206F), Color(0xFF1B1830)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'CREATE • AUTO EDIT • SHARE',
                  style: TextStyle(color: purple, letterSpacing: 1.3),
                ),
                SizedBox(height: 14),
                Text(
                  'Your next viral clip starts here.',
                  style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
                ),
                SizedBox(height: 10),
                Text(
                  'Add your video and let on-device AI help create Shorts and Reels.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _HomeTile(
            icon: Icons.auto_awesome,
            title: 'AI Auto Edit',
            subtitle: 'Upload a video, choose a style or describe your edit.',
            onTap: () => _openEditor(context),
          ),
          _HomeTile(
            icon: Icons.video_library_outlined,
            title: 'Video Editor',
            subtitle: 'Trim, split, crop, add text, music, effects and transitions.',
            onTap: () => _openEditor(context),
          ),
          _HomeTile(
            icon: Icons.subtitles_outlined,
            title: 'Auto Captions',
            subtitle: 'Generate timed captions from speech on your device.',
            onTap: () => _openEditor(context),
          ),
          _HomeTile(
            icon: Icons.folder_open_outlined,
            title: 'My Projects',
            subtitle: 'Open saved drafts and recent edits.',
            onTap: () => _openProjects(context),
          ),
          const SizedBox(height: 18),
          const Text(
            'AI processing is designed to run on your phone. First-time speech/model downloads need internet and free storage.',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              'VIBE NOVA CLIPS • VERSION 3.0',
              style: TextStyle(color: Colors.white38, letterSpacing: 1),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeTile extends StatelessWidget {
  const _HomeTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        color: const Color(0xFF1B1B28),
        margin: const EdgeInsets.only(bottom: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19)),
        child: ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF392653),
            child: Icon(icon, color: const Color(0xFFB88AFF)),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(subtitle),
          ),
          trailing: const Icon(Icons.chevron_right),
        ),
      );
}
